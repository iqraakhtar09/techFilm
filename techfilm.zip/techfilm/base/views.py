from django.shortcuts import render

# Create your views here.


def home(request):
    context = {}
    return render(request, 'base/home.html', context)

def text(request):
    context = {}
    return render(request, 'base/text.html', context)

def voice(request):
    context = {}
    return render(request, 'base/voice.html', context)

def login(request):
    context = {}
    return render(request, 'base/login.html', context)
